import time
import sys

def onlyPrint():
    while True:
        print("This is a python webjob version.")
        sys.stdout.flush()
        time.sleep(15)


onlyPrint()
